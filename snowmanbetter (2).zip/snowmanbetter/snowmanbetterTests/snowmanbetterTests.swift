//
//  snowmanbetterTests.swift
//  snowmanbetterTests
//
//  Created by Connor Dailey on 3/31/25.
//

import Testing
@testable import snowmanbetter

struct snowmanbetterTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
