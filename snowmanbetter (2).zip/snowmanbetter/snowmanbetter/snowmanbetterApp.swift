//
//  snowmanbetterApp.swift
//  snowmanbetter
//
//  Created by Connor Dailey on 3/31/25.
//

import SwiftUI

@main
struct snowmanbetterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
