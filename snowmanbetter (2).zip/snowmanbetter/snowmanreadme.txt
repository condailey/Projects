﻿Readme
Snowman
* snowmanbetter (Main Folder)
   * snowmanbetter (Folder of the Swift files)
      * Assets - contained the icons for the app itself
      * ContentView - (Main program itself, about 35% AI in some sense, including debugging)
      * snowmanbetterApp - (automatically generated, named by us, required to run)
   * snowmanbetterTests (automatically generated, required to run)
      * snowmanbetterTests (automatically generated, required to run)
   * snowmanbetterUITests (automatically generated, required to run)
      * snowmanbetterUITestsLaunchTests (automatically generated, required to run)