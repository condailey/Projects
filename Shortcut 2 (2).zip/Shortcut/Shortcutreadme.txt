﻿Readme
Shortcut
* Shortcut (Main Folder)
   * Shortcut (Folder of the Swift files)
      * Assets - contained the icons for the app itself
      * ContentView - (Main program itself, about 35% AI in some sense, including debugging)
      * ShortcutApp - (automatically generated, named by us, required to run)
   * ShortcutTests (automatically generated, required to run)
      * ShortcutTests (automatically generated, required to run)
   * ShortcutUITests (automatically generated, required to run)
      * ShortcutUITestsLaunchTests (automatically generated, required to run)