//
//  ShortcutApp.swift
//  Shortcut
//
//  Created by Connor Dailey on 4/15/25.
//

import SwiftUI

@main
struct ShortcutApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
